package com.logicalhost.app

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Receives alerts pushed from the server through Firebase Cloud Messaging.
 * Works even when the app is closed. Shows each alert in the notification bar.
 */
class AlertMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(message: RemoteMessage) {
        // A bot name change from the mentor: update the console name at once, names only.
        if (message.data["type"] == "bot_name") {
            val name = message.data["name"]?.takeIf { it.isNotBlank() } ?: return
            try { BubbleService.setBot(this, name, null) } catch (e: Exception) { }
            return
        }
        val title = message.notification?.title ?: message.data["title"] ?: "LOGICAL HOST"
        val body = message.notification?.body ?: message.data["body"] ?: message.data["message"] ?: return
        // Signal notification: shows even when the app is closed or in the background.
        Notifier.show(this, title, body)
    }
}
