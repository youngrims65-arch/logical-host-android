package com.logicalhost.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    private val appUrl = "https://logicalhost.online/android"
    private val appHost = "logicalhost.online"

    // Notifications are optional. The background service works either way.
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    // Called by the web page whenever its own Bot START/STOP changes.
    inner class BotBridge {
        // Console messages from the website (the site sends these; it does nothing until it does).
        private var lastText = ""
        private var lastAt = 0L

        @JavascriptInterface
        fun push(text: String, kind: String) {
            val now = System.currentTimeMillis()
            if (text == lastText && now - lastAt < 3000) return
            lastText = text
            lastAt = now
            val tone = when (kind) {
                "exec", "ok", "success" -> "ok"
                "err", "error", "fail" -> "err"
                "warn", "warning" -> "warn"
                "signal" -> "signal"
                else -> "info"
            }
            try { BubbleService.push(this@MainActivity, text, tone) } catch (e: Exception) { }
        }

        // The bot's name and picture, shown in the console header.
        @JavascriptInterface
        fun setBot(name: String, picUrl: String) {
            try { BubbleService.setBot(this@MainActivity, name, picUrl) } catch (e: Exception) { }
        }

        @JavascriptInterface
        fun setBotRunning(on: Boolean) {
            runOnUiThread { onWebBotChanged(on) }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                loadWithOverviewMode = true
                useWideViewPort = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            }

            webViewClient = object : WebViewClient() {
                // Keep app pages inside the WebView; send other links to the browser.
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    val host = uri.host ?: return false
                    if (host == appHost || host.endsWith(".$appHost")) return false
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    return true
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    view?.evaluateJavascript(BOT_WATCH_JS, null)
                    view?.evaluateJavascript(HIDE_LH_LIVE_LIST_JS, null)
                }

                // Simple offline screen if the app page cannot load.
                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    if (request?.isForMainFrame == true) {
                        view?.loadDataWithBaseURL(null, offlineHtml(), "text/html", "UTF-8", null)
                    }
                }
            }
        }
        webView.addJavascriptInterface(BotBridge(), "LogicalHostNative")

        // Login sessions depend on cookies.
        CookieManager.getInstance().setAcceptCookie(true)

        // Keep JavaScript timers running when the app is in the background.
        webView.resumeTimers()

        // STOP EA in the bubble console presses the web app's STOP button.
        BubbleService.stopAction = {
            runOnUiThread {
                webView.evaluateJavascript(
                    """(function(){var b=[].slice.call(document.querySelectorAll('button')).find(function(x){return (x.textContent||'').trim().toUpperCase()==='STOP';});if(b){b.click();return true;}return false;})();""",
                    null
                )
            }
        }

        setContentView(webView)

        if (savedInstanceState == null) {
            // Fresh start (app was closed): drop the cached copy so the latest web app loads.
            // Login cookies are kept, so you stay signed in.
            webView.clearCache(true)
            webView.loadUrl(appUrl)
        } else {
            webView.restoreState(savedInstanceState)
        }

        if (Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        KeepAliveService.start(this)
        askBatteryExemptionOnce()
    }

    // The bot is controlled by the web page. This follows its state and shows or hides the bubble.
    private var botState: Boolean? = null
    private var appVisible = false

    private fun onWebBotChanged(on: Boolean) {
        try {
            applyBotState(on)
        } catch (e: Exception) {
            // Keep the app running even if a service refuses to start or stop.
        }
    }

    private fun applyBotState(on: Boolean) {
        if (botState == on) return
        if (on && !BubbleService.canDraw(this)) {
            if (!appVisible) return  // cannot show the permission screen from the background
            Toast.makeText(
                this,
                "Allow display over other apps to show the bot bubble",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        botState = on
        // With the bot on, Android must not put the app to sleep. Ask once if not exempt.
        if (on && appVisible) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                } catch (e: Exception) { }
            }
        }
        // Saved so KeepAliveService restores the bot state after Android restarts it.
        getSharedPreferences("bot", Context.MODE_PRIVATE).edit().putBoolean("on", on).apply()
        try { KeepAliveService.setBot(this, on) } catch (e: Exception) { }
        val handler = Handler(Looper.getMainLooper())
        if (on) {
            try { BubbleService.start(this) } catch (e: Exception) { }
            handler.postDelayed({ BubbleService.push(this, "Bot online", "ok") }, 800)
        } else {
            try { BubbleService.stop(this) } catch (e: Exception) { }
        }
    }

    // Asks once to be excluded from battery optimisation, so Android does not put the app to sleep.
    private fun askBatteryExemptionOnce() {
        val prefs = getSharedPreferences("startup", Context.MODE_PRIVATE)
        if (prefs.getBoolean("battery_asked", false)) return
        prefs.edit().putBoolean("battery_asked", true).apply()

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
        }
    }

    // The app needs "Display over other apps" to show the bubble, so ask until it is allowed.
    override fun onPause() {
        appVisible = false
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        appVisible = true
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow display over other apps to use LOGICAL HOST", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
    }

    // Back button goes back in the web app first, then exits.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    private fun offlineHtml() = """
        <html><body style="margin:0;height:100vh;display:flex;flex-direction:column;
        align-items:center;justify-content:center;background:#050b1a;color:#e6f0ff;
        font-family:system-ui,sans-serif;text-align:center;gap:16px">
        <h2 style="letter-spacing:3px">LOGICAL HOST</h2>
        <p>Can't reach the app. Check your connection.</p>
        <a href="$appUrl" style="padding:12px 22px;border-radius:12px;background:#1e90ff;
        color:#fff;text-decoration:none;font-weight:700">Try again</a>
        </body></html>
    """.trimIndent()

    companion object {
        // Hides the app's own LIVE ACTIVITY list, so only the bubble console is shown.
        private const val HIDE_LH_LIVE_LIST_JS = """
            (function () {
              if (document.getElementById('lh-native-live-css')) return;
              var style = document.createElement('style');
              style.id = 'lh-native-live-css';
              style.textContent = '.bcon-wrap, .bcon-card, .lh-exec-overlay, .bc-more, .bc-feed, .bc-foot { display: none !important; }';
              document.head.appendChild(style);
            })();
        """

        // Reports the web page's bot state to the app whenever it changes.
        private const val BOT_WATCH_JS = """
            (function () {
              if (window.__botWatch) return;
              window.__botWatch = true;
              var last = null;
              var lastBot = '';
              // Reads the bot's name and picture from the console card on the page, so they
              // reach the bubble even if the website call is missing.
              // The top bot card: its picture is the largest image near the top, and its name is the
              // largest text just below it. Works for round and octagon pictures.
              function findTopBot() {
                try {
                  var H = window.innerHeight, pic = null, best = 0;
                  document.querySelectorAll('img').forEach(function (img) {
                    if (img.closest('.bcon-wrap')) return;
                    var r = img.getBoundingClientRect();
                    if (r.width < 60 || r.top < -20 || r.top > H * 0.45 || r.bottom < H * 0.05) return;
                    var area = r.width * r.height;
                    if (area > best) { best = area; pic = img; }
                  });
                  var name = '', size = 0;
                  document.querySelectorAll('body *').forEach(function (el) {
                    if (el.closest('.bcon-wrap') || el.children.length > 0) return;
                    var t = (el.textContent || '').trim();
                    if (!t || t.length > 40) return;
                    var r = el.getBoundingClientRect();
                    if (r.width === 0 || r.top < 0 || r.top > H * 0.55) return;
                    var f = parseFloat(window.getComputedStyle(el).fontSize) || 0;
                    if (f > size) { size = f; name = t; }
                  });
                  if (!pic || !name) return null;
                  return { name: name, pic: pic.src || '' };
                } catch (e) { return null; }
              }
              function sendBot() {
                try {
                  // Keep the last bot until the top card shows another one (no default overwrite).
                  var top = findTopBot();
                  if (!top || !top.name) return;
                  var name = top.name, pic = top.pic;
                  var key = name + '|' + pic;
                  if (key !== lastBot) {
                    lastBot = key;
                    if (window.LogicalHostNative) window.LogicalHostNative.setBot(name, pic);
                  }
                } catch (e) {}
              }
              // Hides the web app's small round bot bubble, so only the app's bubble shows.
              function hideWebBubble() {
                try {
                  var W = window.innerWidth, H = window.innerHeight;
                  document.querySelectorAll('body *').forEach(function (el) {
                    if (el.getAttribute('data-lh-hidden') === '1') return;
                    var r = el.getBoundingClientRect();
                    if (r.width < 36 || r.width > 110 || Math.abs(r.width - r.height) > 8) return;
                    if (r.left < W * 0.6 || r.top < H * 0.45 || r.bottom > H) return;
                    var cs = window.getComputedStyle(el);
                    var round = parseFloat(cs.borderTopLeftRadius) >= r.width / 3 || cs.borderTopLeftRadius.indexOf('%') >= 0;
                    if (!round) return;
                    var hasPic = el.tagName === 'IMG' || !!el.querySelector('img') || (cs.backgroundImage && cs.backgroundImage !== 'none');
                    if (!hasPic) return;
                    el.setAttribute('data-lh-hidden', '1');
                    el.style.setProperty('display', 'none', 'important');
                  });
                } catch (e) {}
              }
              // Hides the web app's own console card every time it is shown or re-drawn.
              function hideWebConsole() {
                try {
                  if (!document.getElementById('lh-native-live-css')) {
                    var st = document.createElement('style');
                    st.id = 'lh-native-live-css';
                    st.textContent = '.bcon-wrap, .bcon-card, .lh-exec-overlay, .bc-more, .bc-feed, .bc-foot { display: none !important; visibility: hidden !important; pointer-events: none !important; }';
                    (document.head || document.documentElement).appendChild(st);
                  }
                  document.querySelectorAll('.bcon-wrap, .bcon-card, .lh-exec-overlay').forEach(function (el) {
                    el.style.setProperty('display', 'none', 'important');
                  });
                } catch (e) {}
              }
              hideWebConsole();
              setInterval(function () { hideWebBubble(); hideWebConsole(); }, 1000);
            })();
        """
    }
}
