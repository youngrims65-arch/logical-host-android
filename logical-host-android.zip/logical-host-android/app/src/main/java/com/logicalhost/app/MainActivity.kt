package com.logicalhost.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.webkit.CookieManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var botSwitch: Switch

    private val appUrl = "https://logicalhost.online/android"
    private val appHost = "logicalhost.online"

    // Notifications are optional. The background service works either way.
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                loadWithOverviewMode = true
                useWideViewPort = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            }

            webViewClient = object : WebViewClient() {
                // Keep app pages inside the WebView; send other links to the browser.
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    val host = uri.host ?: return false
                    if (host == appHost || host.endsWith(".$appHost")) return false
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    return true
                }

                // Simple offline screen if the app page cannot load.
                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    if (request?.isForMainFrame == true) {
                        view?.loadDataWithBaseURL(null, offlineHtml(), "text/html", "UTF-8", null)
                    }
                }
            }
        }

        // Login sessions depend on cookies.
        CookieManager.getInstance().setAcceptCookie(true)

        // Keep JavaScript timers running when the app is in the background.
        webView.resumeTimers()

        if (savedInstanceState == null) {
            webView.loadUrl(appUrl)
        } else {
            webView.restoreState(savedInstanceState)
        }

        // Bot switch: restores the last state, but only if overlay permission is still granted.
        val botPrefs = getSharedPreferences("bot", Context.MODE_PRIVATE)
        botSwitch = Switch(this).apply {
            isChecked = botPrefs.getBoolean("on", false) && Settings.canDrawOverlays(this@MainActivity)
            setOnCheckedChangeListener { _, checked -> onBotToggled(checked) }
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setBackgroundColor(Color.parseColor("#050b1a"))
            addView(
                TextView(this@MainActivity).apply {
                    text = "Bot"
                    setTextColor(Color.WHITE)
                    textSize = 16f
                },
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
            addView(botSwitch)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(
                bar,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            )
            addView(
                webView,
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            )
        }
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        KeepAliveService.start(this)
        askBatteryExemptionOnce()
    }

    // Turns the bot on or off. Turning it on needs "Display over other apps" first.
    private fun onBotToggled(checked: Boolean) {
        if (checked && !Settings.canDrawOverlays(this)) {
            botSwitch.isChecked = false
            Toast.makeText(
                this,
                "Allow display over other apps, then turn the bot on again",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        getSharedPreferences("bot", Context.MODE_PRIVATE).edit().putBoolean("on", checked).apply()
        KeepAliveService.setBot(this, checked)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    // Asks once to be excluded from battery optimisation, so Android does not put the app to sleep.
    private fun askBatteryExemptionOnce() {
        val prefs = getSharedPreferences("startup", Context.MODE_PRIVATE)
        if (prefs.getBoolean("battery_asked", false)) return
        prefs.edit().putBoolean("battery_asked", true).apply()

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
        }
    }

    // Back button goes back in the web app first, then exits.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    private fun offlineHtml() = """
        <html><body style="margin:0;height:100vh;display:flex;flex-direction:column;
        align-items:center;justify-content:center;background:#050b1a;color:#e6f0ff;
        font-family:system-ui,sans-serif;text-align:center;gap:16px">
        <h2 style="letter-spacing:3px">LOGICAL HOST</h2>
        <p>Can't reach the app. Check your connection.</p>
        <a href="$appUrl" style="padding:12px 22px;border-radius:12px;background:#1e90ff;
        color:#fff;text-decoration:none;font-weight:700">Try again</a>
        </body></html>
    """.trimIndent()
}
