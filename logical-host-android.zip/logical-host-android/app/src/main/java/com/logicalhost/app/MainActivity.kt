package com.logicalhost.app

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val appHost = "logicalhost.online"
    private val appUrl = "https://logicalhost.online/android"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                loadWithOverviewMode = true
                useWideViewPort = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            }

            webViewClient = object : WebViewClient() {
                // Keep app pages inside the WebView; send other links to the browser.
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    if (uri.host?.endsWith(appHost) == true) return false
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    return true
                }

                // Show a simple offline screen if the app page cannot load.
                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    if (request?.isForMainFrame == true) {
                        view?.loadDataWithBaseURL(null, offlineHtml(), "text/html", "UTF-8", null)
                    }
                }
            }
        }

        CookieManager.getInstance().setAcceptCookie(true)

        setContentView(webView)

        if (savedInstanceState == null) {
            webView.loadUrl(appUrl)
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    // Back button goes back in the web app first, then exits.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onPause() {
        webView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    private fun offlineHtml() = """
        <html><body style="margin:0;height:100vh;display:flex;flex-direction:column;
        align-items:center;justify-content:center;background:#050b1a;color:#e6f0ff;
        font-family:system-ui,sans-serif;text-align:center;gap:16px">
        <h2 style="letter-spacing:3px">LOGICAL HOST</h2>
        <p>Can't reach the app. Check your connection.</p>
        <a href="$appUrl" style="padding:12px 22px;border-radius:12px;background:#1e90ff;
        color:#fff;text-decoration:none;font-weight:700">Try again</a>
        </body></html>
    """.trimIndent()
}
