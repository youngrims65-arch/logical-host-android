package com.logicalhost.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.app.NotificationCompat

// Keeps the app running in the background. When the bot is on, it runs a cycle
// every minute and shows a draggable bubble over other apps.
class KeepAliveService : Service() {

    companion object {
        private const val CHANNEL_ID = "keep_alive_min"
        private const val NOTIFICATION_ID = 1
        private const val ACTION_STOP = "com.logicalhost.app.STOP_KEEP_ALIVE"
        private const val ACTION_BOT = "com.logicalhost.app.BOT_SET"
        private const val EXTRA_BOT_ON = "bot_on"
        private const val CYCLE_MS = 60_000L

        fun start(context: Context) {
            val intent = Intent(context, KeepAliveService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun setBot(context: Context, on: Boolean) {
            val intent = Intent(context, KeepAliveService::class.java)
                .setAction(ACTION_BOT)
                .putExtra(EXTRA_BOT_ON, on)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var botOn = false
    private var cycles = 0
    private var windowManager: WindowManager? = null
    private var bubble: ImageView? = null

    private val cycleRunnable = object : Runnable {
        override fun run() {
            cycles++
            runCycle()
            updateBubble()
            goForeground()
            handler.postDelayed(this, CYCLE_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Background running",
            NotificationManager.IMPORTANCE_MIN
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                shutDown()
                return START_NOT_STICKY
            }
            ACTION_BOT -> setBotState(intent?.getBooleanExtra(EXTRA_BOT_ON, false) ?: false)
            else -> setBotState(
                getSharedPreferences("bot", Context.MODE_PRIVATE).getBoolean("on", false)
            )
        }
        goForeground()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        hideBubble()
        super.onDestroy()
    }

    private fun setBotState(requested: Boolean) {
        handler.removeCallbacks(cycleRunnable)
        botOn = requested && Settings.canDrawOverlays(this)
        if (botOn) {
            showBubble()
            handler.postDelayed(cycleRunnable, CYCLE_MS)
        } else {
            hideBubble()
        }
    }

    private fun shutDown() {
        botOn = false
        handler.removeCallbacksAndMessages(null)
        hideBubble()
        // Stop from the notification also turns the bot off, so the switch stays in sync.
        getSharedPreferences("bot", Context.MODE_PRIVATE).edit().putBoolean("on", false).apply()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // TODO: put the bot's cycle logic here (checks, signal polling, alerts).
    // Runs every minute while the bot is on.
    private fun runCycle() {
    }

    private fun showBubble() {
        if (bubble != null || !Settings.canDrawOverlays(this)) return
        val size = (56 * resources.displayMetrics.density).toInt()

        val view = ImageView(this).apply {
            setImageResource(R.drawable.bubble_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }

        val params = WindowManager.LayoutParams(
            size,
            size,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 300
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        view.setOnTouchListener { v: View, e: MotionEvent ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    windowManager?.updateViewLayout(v, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) openApp()
                    true
                }
                else -> false
            }
        }

        windowManager?.addView(view, params)
        bubble = view
        updateBubble()
    }

    private fun hideBubble() {
        bubble?.let {
            try {
                windowManager?.removeView(it)
            } catch (e: IllegalArgumentException) {
                // Already removed.
            }
        }
        bubble = null
    }

    // The bubble is an image now, so there is no text to update.
    private fun updateBubble() {
    }

    private fun openApp() {
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
    }

    private fun goForeground() {
        // Minimal notification: no text, no status bar icon, hidden on the lock screen.
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("")
            .setContentText("")
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .setShowWhen(false)
            .setSilent(true)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }
}
