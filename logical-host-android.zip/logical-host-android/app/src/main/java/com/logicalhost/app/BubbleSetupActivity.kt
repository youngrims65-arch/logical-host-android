package com.logicalhost.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

/**
 * Opens Android's "Display over other apps" switch for LOGICAL HOST,
 * then starts the floating bubble as soon as it is allowed.
 * Started automatically by the app (see MANIFEST-ADD.xml / README).
 */
class BubbleSetupActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 7)
        if (BubbleService.canDraw(this)) { BubbleService.start(this); finish(); return }
        Toast.makeText(this, "Turn on \"Display over other apps\" for LOGICAL HOST", Toast.LENGTH_LONG).show()
        startActivityForResult(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), 9
        )
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (BubbleService.canDraw(this)) BubbleService.start(this)
        else Toast.makeText(this, "Bubble is off — allow \"Display over other apps\" to use it", Toast.LENGTH_LONG).show()
        finish()
    }
}
