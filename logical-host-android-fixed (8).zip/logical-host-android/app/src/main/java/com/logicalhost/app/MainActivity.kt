package com.logicalhost.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    // Gallery picker for web upload buttons (for example, a bot picture). Without this, the web
    // page's file button does nothing inside the app.
    private var fileCallback: android.webkit.ValueCallback<Array<android.net.Uri>>? = null
    private val filePicker = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        fileCallback?.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
        fileCallback = null
    }

    private val appUrl = "https://logicalhost.online/android"
    private val appHost = "logicalhost.online"

    // Notifications are optional. The background service works either way.
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    // Called by the web page whenever its own Bot START/STOP changes.
    inner class BotBridge {
        // Console messages from the website (the site sends these; it does nothing until it does).
        private var lastText = ""
        private var lastAt = 0L

        @JavascriptInterface
        fun push(rawText: String?, rawKind: String?) {
            // Empty values instead of null: a null from the web page used to crash the app.
            val text = rawText ?: ""
            val kind = rawKind ?: "info"
            val now = System.currentTimeMillis()
            if (text == lastText && now - lastAt < 3000) return
            lastText = text
            lastAt = now
            val tone = when (kind) {
                "exec", "ok", "success" -> "ok"
                "err", "error", "fail" -> "err"
                "warn", "warning" -> "warn"
                "signal" -> "signal"
                else -> "info"
            }
            try { BubbleService.push(this@MainActivity, text, tone) } catch (e: Exception) { }
        }

        // The bot's name and picture, shown in the console header.
        @JavascriptInterface
        fun setBot(rawName: String?, rawPic: String?) {
            val name = rawName ?: ""
            val picUrl = rawPic ?: ""
            try { BubbleService.setBot(this@MainActivity, name, picUrl) } catch (e: Exception) { }
        }

        // The web page sends its news alert list here. The phone fires each one at its time.
        @JavascriptInterface
        fun scheduleAlerts(json: String?) {
            try { NewsAlarms.schedule(this@MainActivity, json ?: "[]") } catch (e: Exception) { }
        }

        @JavascriptInterface
        fun clearAlerts() {
            try { NewsAlarms.clear(this@MainActivity) } catch (e: Exception) { }
        }

        // Shows a notification from the web page, for example a news alert before an event.
        @JavascriptInterface
        fun showAlert(rawTitle: String?, rawBody: String?) {
            try {
                Notifier.show(this@MainActivity, rawTitle?.takeIf { it.isNotBlank() } ?: "LOGICAL HOST", rawBody ?: "")
            } catch (e: Exception) { }
        }

        @JavascriptInterface
        fun setBotRunning(on: Boolean) {
            runOnUiThread { onWebBotChanged(on) }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                loadWithOverviewMode = true
                useWideViewPort = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            }

            webViewClient = object : WebViewClient() {
                // Keep app pages inside the WebView; send other links to the browser.
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    val host = uri.host ?: return false
                    if (host == appHost || host.endsWith(".$appHost")) return false
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    return true
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    view?.evaluateJavascript(BOT_WATCH_JS, null)
                    view?.evaluateJavascript(HIDE_LH_LIVE_LIST_JS, null)
                }

                // If Android kills the page's process, reload it instead of closing the app.
                override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                    view?.post { view.reload() }
                    return true
                }

                // Simple offline screen if the app page cannot load.
                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    if (request?.isForMainFrame == true) {
                        view?.loadDataWithBaseURL(null, offlineHtml(), "text/html", "UTF-8", null)
                    }
                }
            }
        }
        webView.addJavascriptInterface(BotBridge(), "LogicalHostNative")
        // Lets the web page open the gallery, for example to upload a bot picture.
        webView.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                callback: android.webkit.ValueCallback<Array<android.net.Uri>>?,
                params: android.webkit.WebChromeClient.FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val type = if (params?.acceptTypes?.any { it.startsWith("image") } == true) "image/*" else "*/*"
                return try {
                    filePicker.launch(type)
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    callback?.onReceiveValue(null)
                    false
                }
            }
        }

        // Login sessions depend on cookies.
        CookieManager.getInstance().setAcceptCookie(true)

        // Keep JavaScript timers running when the app is in the background.
        webView.resumeTimers()

        // STOP EA in the bubble console presses the web app's STOP button.
        BubbleService.stopAction = {
            runOnUiThread {
                webView.evaluateJavascript(
                    """(function(){var b=[].slice.call(document.querySelectorAll('button')).find(function(x){return (x.textContent||'').trim().toUpperCase()==='STOP';});if(b){b.click();return true;}return false;})();""",
                    null
                )
            }
        }

        setContentView(webView)

        if (savedInstanceState == null) {
            // Fresh start (app was closed): drop the cached copy so the latest web app loads.
            // Login cookies are kept, so you stay signed in.
            webView.clearCache(true)
            // Clear stale bubble state from the last session; the web switch sets the real state.
            botState = null
            getSharedPreferences("bot", Context.MODE_PRIVATE).edit().putBoolean("on", false).apply()
            try { BubbleService.stop(this) } catch (e: Exception) { }
            try { KeepAliveService.setBot(this, false) } catch (e: Exception) { }
            webView.loadUrl(appUrl)
        } else {
            webView.restoreState(savedInstanceState)
        }

        if (Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        KeepAliveService.start(this)
        askBatteryExemptionOnce()
        // Server alerts are sent to this topic, so no per-phone token is needed.
        try {
            com.google.firebase.messaging.FirebaseMessaging.getInstance().subscribeToTopic("logical_host_alerts")
        } catch (e: Exception) { }
    }

    // The bot is controlled by the web page. This follows its state and shows or hides the bubble.
    private var botState: Boolean? = null
    private var appVisible = false

    // Taps on the switch are settled before anything starts or stops. Fast repeated taps
    // would otherwise start and stop the bubble service at the same moment and crash the app.
    private val botHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var pendingBot: Boolean? = null
    private val applyPendingBot = Runnable {
        val want = pendingBot ?: return@Runnable
        pendingBot = null
        try {
            applyBotState(want)
        } catch (e: Exception) {
            // Keep the app running even if a service refuses to start or stop.
        }
    }

    private var lastBotApply = 0L

    private fun onWebBotChanged(on: Boolean) {
        val now = System.currentTimeMillis()
        if (now - lastBotApply >= 1200) {
            // A tap after a pause: apply it now, so the bubble appears or disappears at once.
            lastBotApply = now
            pendingBot = null
            botHandler.removeCallbacks(applyPendingBot)
            try { applyBotState(on) } catch (e: Exception) { }
            return
        }
        // Fast repeated taps: only the latest one counts, applied once the taps stop.
        lastBotApply = now
        pendingBot = on
        botHandler.removeCallbacks(applyPendingBot)
        botHandler.postDelayed(applyPendingBot, 1200)
    }

    // Asks once to be excluded from battery optimisation, so the bot keeps running in the background.
    private fun askBatteryOnce() {
        val prefs = getSharedPreferences("startup", Context.MODE_PRIVATE)
        if (prefs.getBoolean("battery_on_asked", false)) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) return
        prefs.edit().putBoolean("battery_on_asked", true).apply()
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (e: Exception) { }
    }

    private fun applyBotState(on: Boolean) {
        if (botState == on) return
        if (on && !BubbleService.canDraw(this)) {
            if (!appVisible) return  // cannot show the permission screen from the background
            Toast.makeText(
                this,
                "Allow display over other apps to show the bot bubble",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        botState = on
        // Saved so KeepAliveService restores the bot state after Android restarts it.
        getSharedPreferences("bot", Context.MODE_PRIVATE).edit().putBoolean("on", on).apply()
        try { KeepAliveService.setBot(this, on) } catch (e: Exception) { }
        val handler = Handler(Looper.getMainLooper())
        if (on) {
            try { BubbleService.start(this) } catch (e: Exception) { }
            // Ask about battery use once, after the bubble is already showing.
            if (appVisible) askBatteryOnce()
            handler.postDelayed({ BubbleService.push(this, "Bot online", "ok") }, 800)
        } else {
            try { BubbleService.stop(this) } catch (e: Exception) { }
        }
    }

    // Asks once to be excluded from battery optimisation, so Android does not put the app to sleep.
    private fun askBatteryExemptionOnce() {
        val prefs = getSharedPreferences("startup", Context.MODE_PRIVATE)
        if (prefs.getBoolean("battery_asked", false)) return
        prefs.edit().putBoolean("battery_asked", true).apply()

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
        }
    }

    // The app needs "Display over other apps" to show the bubble, so ask until it is allowed.
    override fun onPause() {
        appVisible = false
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        appVisible = true
        // If the bot is on, make sure the bubble is showing again (it may have been dismissed).
        if (botState == true) try { BubbleService.start(this) } catch (e: Exception) { }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow display over other apps to use LOGICAL HOST", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
    }

    // Back button goes back in the web app first, then exits.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    private fun offlineHtml() = """
        <html><body style="margin:0;height:100vh;display:flex;flex-direction:column;
        align-items:center;justify-content:center;background:#050b1a;color:#e6f0ff;
        font-family:system-ui,sans-serif;text-align:center;gap:16px">
        <h2 style="letter-spacing:3px">LOGICAL HOST</h2>
        <p>Can't reach the app. Check your connection.</p>
        <a href="$appUrl" style="padding:12px 22px;border-radius:12px;background:#1e90ff;
        color:#fff;text-decoration:none;font-weight:700">Try again</a>
        </body></html>
    """.trimIndent()

    companion object {
        // Hides the app's own LIVE ACTIVITY list, so only the bubble console is shown.
        private const val HIDE_LH_LIVE_LIST_JS = """
            (function () {
              if (document.getElementById('lh-native-live-css')) return;
              var style = document.createElement('style');
              style.id = 'lh-native-live-css';
              style.textContent = '.bcon-wrap, .bcon-card, .lh-exec-overlay, .bc-more, .bc-feed, .bc-foot { display: none !important; }';
              document.head.appendChild(style);
            })();
        """

        // Reports the web page's bot state to the app whenever it changes.
        private const val BOT_WATCH_JS = """
            (function () {
              if (window.__botWatch) return;
              window.__botWatch = true;
              var last = null;
              var lastBot = '';
              // Reads the bot's name and picture from the console card on the page, so they
              // reach the bubble even if the website call is missing.
              // The top bot card: its picture is the largest image near the top, and its name is the
              // largest text just below it. Works for round and octagon pictures.
              function findTopBot() {
                try {
                  var H = window.innerHeight, pic = null, best = 0;
                  document.querySelectorAll('img').forEach(function (img) {
                    if (img.closest('.bcon-wrap')) return;
                    var r = img.getBoundingClientRect();
                    if (r.width < 60 || r.top < -20 || r.top > H * 0.45 || r.bottom < H * 0.05) return;
                    var area = r.width * r.height;
                    if (area > best) { best = area; pic = img; }
                  });
                  var name = '', size = 0;
                  document.querySelectorAll('body *').forEach(function (el) {
                    if (el.closest('.bcon-wrap') || el.children.length > 0) return;
                    var t = (el.textContent || '').trim();
                    if (!t || t.length > 40) return;
                    var r = el.getBoundingClientRect();
                    if (r.width === 0 || r.top < 0 || r.top > H * 0.55) return;
                    var f = parseFloat(window.getComputedStyle(el).fontSize) || 0;
                    if (f > size) { size = f; name = t; }
                  });
                  if (!pic || !name) return null;
                  return { name: name, pic: pic.src || '' };
                } catch (e) { return null; }
              }
              function sendBot() {
                try {
                  // Keep the last bot until the top card shows another one (no default overwrite).
                  var top = findTopBot();
                  if (!top || !top.name) return;
                  var name = top.name, pic = top.pic;
                  var key = name + '|' + pic;
                  if (key !== lastBot) {
                    lastBot = key;
                    if (window.LogicalHostNative) window.LogicalHostNative.setBot(name, pic);
                  }
                } catch (e) {}
              }
              // Hides the web app's small round bot bubble, so only the app's bubble shows.
              function hideWebBubble() {
                try {
                  var W = window.innerWidth, H = window.innerHeight;
                  document.querySelectorAll('body *').forEach(function (el) {
                    if (el.getAttribute('data-lh-hidden') === '1') return;
                    var r = el.getBoundingClientRect();
                    if (r.width < 36 || r.width > 200 || Math.abs(r.width - r.height) > 8) return;
                    // The web bubble sits either bottom-right (small) or bottom-centre (larger).
                    var cornerBubble = r.left >= W * 0.6 && r.top >= H * 0.45 && r.bottom <= H && r.width <= 110;
                    var bottomMiddle = r.top >= H * 0.7 && r.bottom <= H && r.left >= W * 0.25 && r.right <= W * 0.75;
                    if (!cornerBubble && !bottomMiddle) return;
                    var cs = window.getComputedStyle(el);
                    var round = parseFloat(cs.borderTopLeftRadius) >= r.width / 3 || cs.borderTopLeftRadius.indexOf('%') >= 0;
                    if (!round) return;
                    var hasPic = el.tagName === 'IMG' || !!el.querySelector('img') || (cs.backgroundImage && cs.backgroundImage !== 'none');
                    if (!hasPic) return;
                    el.setAttribute('data-lh-hidden', '1');
                    el.style.setProperty('display', 'none', 'important');
                  });
                } catch (e) {}
              }
              // Hides any small floating picture the web app draws on top of the screen (such as the robot bubble).
              function hideFloatingWebImages() {
                try {
                  var report = [];
                  document.querySelectorAll('body *').forEach(function (el) {
                    if (el.getAttribute('data-lh-hidden') === '1') return;
                    var cs = window.getComputedStyle(el);
                    if (cs.position !== 'fixed' && cs.position !== 'absolute') return;
                    var r = el.getBoundingClientRect();
                    if (r.width < 36 || r.width > 260 || r.height < 36 || r.height > 260) return;
                    var hasPic = el.tagName === 'IMG' || !!el.querySelector('img') || (cs.backgroundImage && cs.backgroundImage !== 'none');
                    if (!hasPic) return;
                    el.setAttribute('data-lh-hidden', '1');
                    el.style.setProperty('display', 'none', 'important');
                    if (report.length < 3) report.push(el.tagName + '#' + el.id + '.' + String(el.className && el.className.baseVal !== undefined ? el.className.baseVal : el.className).slice(0, 40) + ' ' + Math.round(r.width) + 'x' + Math.round(r.height));
                  });
                  if (report.length && !window.__lhReported && window.LogicalHostNative) {
                    window.__lhReported = true;
                    try { window.LogicalHostNative.push('HIDDEN WEB BUBBLE: ' + report.join(' | '), 'info') } catch (e) {}
                  }
                } catch (e) {}
              }
              // Hides the web app's own console card every time it is shown or re-drawn.
              function hideWebConsole() {
                try {
                  if (!document.getElementById('lh-native-live-css')) {
                    var st = document.createElement('style');
                    st.id = 'lh-native-live-css';
                    st.textContent = '.bcon-wrap, .bcon-card, .lh-exec-overlay, .bc-more, .bc-feed, .bc-foot { display: none !important; visibility: hidden !important; pointer-events: none !important; }';
                    (document.head || document.documentElement).appendChild(st);
                  }
                  document.querySelectorAll('.bcon-wrap, .bcon-card, .lh-exec-overlay').forEach(function (el) {
                    el.style.setProperty('display', 'none', 'important');
                  });
                } catch (e) {}
              }
              hideWebConsole();
              setInterval(function () { hideWebBubble(); hideFloatingWebImages(); hideWebConsole(); }, 1000);
            })();
        """
    }
}
