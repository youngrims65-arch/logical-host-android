package com.logicalhost.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray

// Schedules news alerts on the phone, so they fire even when the app is closed.
// The web page sends the whole list each time: [{ "id", "time" (epoch ms), "title", "body" }].
object NewsAlarms {
    private const val PREFS = "news_alerts"
    private const val KEY_IDS = "ids"

    fun schedule(ctx: Context, json: String) {
        clear(ctx)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val arr = JSONArray(json)
        val now = System.currentTimeMillis()
        val ids = mutableSetOf<String>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val time = o.optLong("time", 0L)
            if (time <= now) continue // already past: never alert for old events
            val id = o.optString("id", "$time-$i")
            val intent = Intent(ctx, NewsAlarmReceiver::class.java).apply {
                putExtra("title", o.optString("title", "NEW NEWS"))
                putExtra("body", o.optString("body", ""))
            }
            val pi = PendingIntent.getBroadcast(
                ctx, id.hashCode(), intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi)
            ids.add(id)
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putStringSet(KEY_IDS, ids).apply()
    }

    fun clear(ctx: Context) {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val ids = prefs.getStringSet(KEY_IDS, emptySet()) ?: emptySet()
        for (id in ids) {
            val pi = PendingIntent.getBroadcast(
                ctx, id.hashCode(), Intent(ctx, NewsAlarmReceiver::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE
            )
            if (pi != null) {
                am.cancel(pi)
                pi.cancel()
            }
        }
        prefs.edit().remove(KEY_IDS).apply()
    }
}
