package com.logicalhost.app

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Receives alerts pushed from the server through Firebase Cloud Messaging.
 * Works even when the app is closed. Shows each alert in the notification bar.
 */
class AlertMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(message: RemoteMessage) {
        val title = message.notification?.title ?: message.data["title"] ?: "LOGICAL HOST"
        val body = message.notification?.body ?: message.data["body"] ?: message.data["message"] ?: return
        // Signal notification: shows even when the app is closed or in the background.
        Notifier.show(this, title, body)
    }
}
