package com.logicalhost.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

// Fires at the scheduled time and shows the news notification.
class NewsAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "NEW NEWS"
        val body = intent.getStringExtra("body") ?: ""
        Notifier.show(context, title, body)
    }
}
