package com.logicalhost.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat

// Keeps the app running in the background. While the bot is on, it runs a cycle every minute.
// The floating bubble and console are handled by BubbleService.
class KeepAliveService : Service() {

    companion object {
        private const val CHANNEL_ID = "keep_alive_min"
        private const val NOTIFICATION_ID = 1
        private const val ACTION_BOT = "com.logicalhost.app.BOT_SET"
        private const val EXTRA_BOT_ON = "bot_on"
        private const val CYCLE_MS = 60_000L

        fun start(context: Context) {
            try {
                val intent = Intent(context, KeepAliveService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) { }
        }

        fun setBot(context: Context, on: Boolean) {
            try {
                val intent = Intent(context, KeepAliveService::class.java)
                    .setAction(ACTION_BOT)
                    .putExtra(EXTRA_BOT_ON, on)
                context.startService(intent)
            } catch (e: Exception) { }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var botOn = false
    private var cycles = 0
    private var wakeLock: PowerManager.WakeLock? = null

    private val cycleRunnable = object : Runnable {
        override fun run() {
            cycles++
            runCycle()
            handler.postDelayed(this, CYCLE_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Background running",
            NotificationManager.IMPORTANCE_MIN
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val on = if (intent?.action == ACTION_BOT) {
            intent.getBooleanExtra(EXTRA_BOT_ON, false)
        } else {
            getSharedPreferences("bot", Context.MODE_PRIVATE).getBoolean("on", false)
        }
        // Must call startForeground promptly after a startForegroundService call, so do it first.
        try {
            goForeground()
        } catch (e: Exception) {
            // Android refused the foreground start (e.g. started from the background). Do not crash.
            stopSelf()
            return START_NOT_STICKY
        }
        setBotState(on)
        if (!on) {
            // Bot is off: stop the background service so the app stops running in the background.
            try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) { }
            stopSelf()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        releaseWakeLock()
        super.onDestroy()
    }

    private fun setBotState(on: Boolean) {
        handler.removeCallbacks(cycleRunnable)
        botOn = on
        if (botOn) {
            // Keeps the processor awake with the screen off, so the cycle keeps running.
            acquireWakeLock()
            handler.postDelayed(cycleRunnable, CYCLE_MS)
        } else {
            releaseWakeLock()
        }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LogicalHost:bot").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    // TODO: put the bot's cycle logic here (checks, signal polling, alerts).
    // Runs every minute while the bot is on.
    private fun runCycle() {
    }

    private fun goForeground() {
        // Minimal notification: no text, no status bar icon, hidden on the lock screen.
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("")
            .setContentText("")
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .setShowWhen(false)
            .setSilent(true)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }
}
