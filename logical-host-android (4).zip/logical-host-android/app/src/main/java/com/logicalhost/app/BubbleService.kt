package com.logicalhost.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import kotlin.math.abs

/**
 * LOGICAL HOST floating bubble.
 *  - A round robot bubble floats over every other app (needs "Display over other apps").
 *  - Drag it anywhere; let go and it snaps to the nearest side.
 *  - Drag it onto the X at the bottom to hide it.
 *  - TAP it to open the bot console (assets/lh-console.html, same look as in the app).
 *
 * Send a message to the console from anywhere in the app:
 *   BubbleService.push(context, "SIGNAL RECEIVED — BUY XAUUSD", "signal")
 * kinds: signal, info, exec, ok, warn, err
 */
class BubbleService : Service() {

    companion object {
        const val ACTION_PUSH = "com.logicalhost.app.CONSOLE_PUSH"
        const val ACTION_BOT = "com.logicalhost.app.CONSOLE_BOT"
        private const val CHANNEL = "lh_bubble"
        private const val APP_URL = "https://logicalhost.online/android"

        fun canDraw(ctx: Context) = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx)

        // Called by the app when the web switch turns the bot on. Opens the console too.
        var stopAction: (() -> Unit)? = null

        fun start(ctx: Context, openConsole: Boolean = false) {
            if (!canDraw(ctx)) return
            ContextCompat.startForegroundService(
                ctx, Intent(ctx, BubbleService::class.java).putExtra("open", openConsole)
            )
        }

        fun stop(ctx: Context) = ctx.stopService(Intent(ctx, BubbleService::class.java))

        fun push(ctx: Context, text: String, kind: String = "info") {
            ctx.sendBroadcast(Intent(ACTION_PUSH).setPackage(ctx.packageName)
                .putExtra("text", text).putExtra("kind", kind))
        }

        fun setBot(ctx: Context, name: String, picUrl: String? = null) {
            ctx.sendBroadcast(Intent(ACTION_BOT).setPackage(ctx.packageName)
                .putExtra("name", name).putExtra("pic", picUrl))
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var bubble: ImageView
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private var trash: View? = null
    private var console: LinearLayout? = null
    private var web: WebView? = null
    private var pageReady = false
    private val waiting = mutableListOf<String>()

    private val overlayType
        get() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.getBooleanExtra("open", false) == true) {
            bubble.post { if (console?.isAttachedToWindow != true) toggleConsole() }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(41, notification())
        addBubble()
        buildConsole()
        val f = IntentFilter().apply { addAction(ACTION_PUSH); addAction(ACTION_BOT) }
        ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(receiver) }
        runCatching { wm.removeView(bubble) }
        console?.let { c -> if (c.isAttachedToWindow) runCatching { wm.removeView(c) } }
        trash?.let { t -> if (t.isAttachedToWindow) runCatching { wm.removeView(t) } }
        val w = web
        web = null
        try { w?.destroy() } catch (e: Exception) { }
        super.onDestroy()
    }

    // ---------------- notification (Android needs one while the bubble is showing) ----------------
    private fun notification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Floating bot", NotificationManager.IMPORTANCE_MIN))
        }
        val open = PendingIntent.getActivity(this, 0, appIntent(), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.lh_bubble_logo)
            .setContentTitle("")
            .setContentText("")
            .setContentIntent(open)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    private fun appIntent() = Intent(Intent.ACTION_VIEW, Uri.parse(APP_URL))
        .setPackage(packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        .let { if (it.resolveActivity(packageManager) != null) it
               else (packageManager.getLaunchIntentForPackage(packageName) ?: it).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }

    // ---------------- the bubble ----------------
    @SuppressLint("ClickableViewAccessibility")
    private fun addBubble() {
        bubble = ImageView(this).apply {
            // Transparent logo only, no background circle.
            setImageResource(R.drawable.bubble_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(0, 0, 0, 0)
            contentDescription = "LOGICAL HOST console"
        }
        bubbleLp = WindowManager.LayoutParams(
            dp(62), dp(62), overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = dp(180) }
        wm.addView(bubble, bubbleLp)

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        bubble.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = bubbleLp.x; startY = bubbleLp.y; moved = false
                    v.animate().scaleX(.9f).scaleY(.9f).setDuration(120).start()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (!moved && (abs(dx) > dp(6) || abs(dy) > dp(6))) { moved = true; showTrash(true); hideConsole() }
                    if (moved) { bubbleLp.x = startX + dx.toInt(); bubbleLp.y = startY + dy.toInt(); wm.updateViewLayout(bubble, bubbleLp) }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(160).setInterpolator(OvershootInterpolator()).start()
                    showTrash(false)
                    if (!moved) toggleConsole()
                    else if (overTrash(e.rawY)) stopSelf()
                    else snapToSide()
                }
            }
            true
        }
    }

    private fun snapToSide() {
        val w = resources.displayMetrics.widthPixels
        bubbleLp.x = if (bubbleLp.x + dp(31) < w / 2) 0 else w - dp(62)
        bubbleLp.y = bubbleLp.y.coerceIn(dp(24), resources.displayMetrics.heightPixels - dp(140))
        wm.updateViewLayout(bubble, bubbleLp)
    }

    private fun overTrash(rawY: Float) = rawY > resources.displayMetrics.heightPixels - dp(150)

    private fun showTrash(show: Boolean) {
        if (show && trash == null) {
            trash = ImageView(this).apply {
                setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
                background = ContextCompat.getDrawable(this@BubbleService, R.drawable.lh_bubble_bg)
                val p = dp(14); setPadding(p, p, p, p)
            }
            val lp = WindowManager.LayoutParams(dp(56), dp(56), overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(48) }
            wm.addView(trash, lp)
        } else if (!show) {
            trash?.let { runCatching { wm.removeView(it) } }; trash = null
        }
    }

    // ---------------- the console (tap the bubble) ----------------
    @SuppressLint("SetJavaScriptEnabled")
    private fun buildConsole() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val wv = WebView(this).apply {
            setBackgroundColor(0)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "LH")
            webViewClient = object : android.webkit.WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    pageReady = true
                    waiting.forEach { evaluateJavascript(it, null) }; waiting.clear()
                }
            }
            loadUrl("file:///android_asset/lh-console.html")
        }
        box.addView(wv, LinearLayout.LayoutParams(dp(320), LinearLayout.LayoutParams.WRAP_CONTENT))
        // tap outside the card closes it
        box.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) hideConsole(); false }
        web = wv; console = box
    }

    private fun consoleLp() = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
        PixelFormat.TRANSLUCENT
    ).apply {
        val w = resources.displayMetrics.widthPixels
        gravity = Gravity.TOP or Gravity.START
        x = ((w - dp(320)) / 2).coerceAtLeast(dp(8))
        y = (bubbleLp.y + dp(70)).coerceAtMost(resources.displayMetrics.heightPixels - dp(520)).coerceAtLeast(dp(24))
    }

    private fun toggleConsole() {
        val c = console ?: return
        if (c.isAttachedToWindow) hideConsole()
        else {
            wm.addView(c, consoleLp())
            bubble.visibility = android.view.View.GONE
            c.alpha = 0f; c.translationY = dp(18).toFloat(); c.scaleX = .92f; c.scaleY = .92f
            c.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(450)
                .setInterpolator(android.view.animation.PathInterpolator(.32f, .72f, 0f, 1f)).start()
        }
    }

    private fun hideConsole() {
        val c = console ?: return
        if (c.isAttachedToWindow) runCatching { wm.removeView(c) }
        bubble.visibility = android.view.View.VISIBLE
    }

    private fun js(code: String) {
        val wv = web ?: return
        if (pageReady) {
            wv.post { try { wv.evaluateJavascript(code, null) } catch (e: Exception) { } }
        } else if (waiting.size < 50) waiting += code
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                ACTION_PUSH -> js("lhPush(${JSONObject.quote(i.getStringExtra("text") ?: "")},${JSONObject.quote(i.getStringExtra("kind") ?: "info")})")
                ACTION_BOT -> js("lhSetBot(${JSONObject.quote(i.getStringExtra("name") ?: "")},${JSONObject.quote(i.getStringExtra("pic") ?: "")})")
            }
        }
    }

    /** Buttons inside the console page call these. */
    inner class Bridge {
        @JavascriptInterface fun closeConsole() { bubble.post { hideConsole() } }
        @JavascriptInterface fun openApp() { bubble.post { hideConsole(); startActivity(appIntent()) } }
        @JavascriptInterface fun resize() { bubble.post { console?.requestLayout() } }
        @JavascriptInterface fun cleared() {}
    }
}
