package com.logicalhost.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    private val appUrl = "https://logicalhost.online/android"
    private val appHost = "logicalhost.online"

    // Notifications are optional. The background service works either way.
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    // Called by the web page whenever its own Bot START/STOP changes.
    inner class BotBridge {
        // Console messages from the website (the site sends these; it does nothing until it does).
        @JavascriptInterface
        fun push(text: String, signal: Boolean) {
            BubbleService.push(this@MainActivity, text, if (signal) "signal" else "info")
        }

        @JavascriptInterface
        fun setBotRunning(on: Boolean) {
            runOnUiThread { onWebBotChanged(on) }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                loadWithOverviewMode = true
                useWideViewPort = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            }

            webViewClient = object : WebViewClient() {
                // Keep app pages inside the WebView; send other links to the browser.
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    val host = uri.host ?: return false
                    if (host == appHost || host.endsWith(".$appHost")) return false
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    return true
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    view?.evaluateJavascript(BOT_WATCH_JS, null)
                }

                // Simple offline screen if the app page cannot load.
                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    if (request?.isForMainFrame == true) {
                        view?.loadDataWithBaseURL(null, offlineHtml(), "text/html", "UTF-8", null)
                    }
                }
            }
        }
        webView.addJavascriptInterface(BotBridge(), "LogicalHostNative")

        // Login sessions depend on cookies.
        CookieManager.getInstance().setAcceptCookie(true)

        // Keep JavaScript timers running when the app is in the background.
        webView.resumeTimers()

        // STOP EA in the bubble console presses the web app's STOP button.
        BubbleService.stopAction = {
            runOnUiThread {
                webView.evaluateJavascript(
                    """(function(){var b=[].slice.call(document.querySelectorAll('button')).find(function(x){return (x.textContent||'').trim().toUpperCase()==='STOP';});if(b){b.click();return true;}return false;})();""",
                    null
                )
            }
        }

        setContentView(webView)

        if (savedInstanceState == null) {
            webView.loadUrl(appUrl)
        } else {
            webView.restoreState(savedInstanceState)
        }

        if (Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        KeepAliveService.start(this)
        askBatteryExemptionOnce()
    }

    // The bot is controlled by the web page. This follows its state and shows or hides the bubble.
    private fun onWebBotChanged(on: Boolean) {
        if (on && !BubbleService.canDraw(this)) {
            Toast.makeText(
                this,
                "Allow display over other apps to show the bot bubble",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        KeepAliveService.setBot(this, on)
        val handler = Handler(Looper.getMainLooper())
        if (on) {
            BubbleService.start(this, openConsole = true)
            handler.postDelayed({ BubbleService.push(this, "Bot online", "ok") }, 800)
        } else {
            handler.postDelayed({ BubbleService.push(this, "Bot offline", "info") }, 0)
            handler.postDelayed({ BubbleService.stop(this) }, 800)
        }
    }

    // Asks once to be excluded from battery optimisation, so Android does not put the app to sleep.
    private fun askBatteryExemptionOnce() {
        val prefs = getSharedPreferences("startup", Context.MODE_PRIVATE)
        if (prefs.getBoolean("battery_asked", false)) return
        prefs.edit().putBoolean("battery_asked", true).apply()

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
        }
    }

    // Back button goes back in the web app first, then exits.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    private fun offlineHtml() = """
        <html><body style="margin:0;height:100vh;display:flex;flex-direction:column;
        align-items:center;justify-content:center;background:#050b1a;color:#e6f0ff;
        font-family:system-ui,sans-serif;text-align:center;gap:16px">
        <h2 style="letter-spacing:3px">LOGICAL HOST</h2>
        <p>Can't reach the app. Check your connection.</p>
        <a href="$appUrl" style="padding:12px 22px;border-radius:12px;background:#1e90ff;
        color:#fff;text-decoration:none;font-weight:700">Try again</a>
        </body></html>
    """.trimIndent()

    companion object {
        // Reports the web page's bot state to the app whenever it changes.
        private const val BOT_WATCH_JS = """
            (function () {
              if (window.__botWatch) return;
              window.__botWatch = true;
              var last = null;
              function check() {
                var on = false;
                try { var c = window.__lhClient; on = !!(c && c.runState && c.runState !== 'idle'); } catch (e) {}
                if (on !== last) {
                  last = on;
                  if (window.LogicalHostNative) window.LogicalHostNative.setBotRunning(on);
                }
              }
              check();
              setInterval(check, 1000);
            })();
        """
    }
}
